﻿using AutoMapper;
using InterviewManagement.Domain.Entities;
using InterviewManagement.Model.Request;
using InterviewManagement.Model.Response;

namespace InterviewManagement.Model
{
    public class InterviewManagementProfile : Profile
    {
        public InterviewManagementProfile()
        {
            CreateMap<CandidateRetrievalRequestDto, Candidate>()
                .ForMember(dest => dest.FName, opt => opt.MapFrom(src => src.FirstName)) ;

            CreateMap<Candidate, CandidateModel>()
                .ForMember(dest=> dest.FirstName, opt=> opt.MapFrom(src=>src.FName))
                .ForMember(dest => dest.MiddleName, opt => opt.MapFrom(src => src.MName))
                .ForMember(dest => dest.LastName, opt => opt.MapFrom(src => src.LName))
                .ForMember(dest => dest.FullName, act => act.Ignore());


            CreateMap<CandidateRegisterRequestDto, Candidate>()
                .ForMember(dest => dest.FName, opt => opt.MapFrom(src => src.FirstName))
                .ForMember(dest => dest.MName, opt => opt.MapFrom(src => src.MiddleName))
                .ForMember(dest => dest.LName, opt => opt.MapFrom(src => src.LastName));

            CreateMap<Candidate, CandidateRegisterResponseDto>()
                .ForMember(dest => dest.FirstName, opt => opt.MapFrom(src => src.FName))
                .ForMember(dest => dest.MiddleName, opt => opt.MapFrom(src => src.MName))
                .ForMember(dest => dest.LastName, opt => opt.MapFrom(src => src.LName));
        }
    }
}
