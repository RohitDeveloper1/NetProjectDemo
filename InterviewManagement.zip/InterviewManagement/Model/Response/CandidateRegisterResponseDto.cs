﻿using InterviewManagement.Model.Response;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace InterviewManagement.Model.Request
{
    public class CandidateRegisterResponseDto : BaseResponseDto
    {
        public string CandidateId { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string Gender { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Pincode { get; set; }
        public decimal Salary { get; set; }
    }
}
