﻿namespace InterviewManagement.Model.Response
{
    public class AuthenticatedResponseDto : BaseResponseDto
    {
        public string? Token { get; set; }
        public string? RefreshToken { get; set; }
    }
}
