﻿namespace InterviewManagement.Model.Response
{
    public class BaseResponseDto
    {
        public bool IsSuccess { get; set; } = false;
        public string ErrorMessage { get; set; } = "";

    }
}
