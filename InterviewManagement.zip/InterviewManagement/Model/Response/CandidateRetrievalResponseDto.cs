﻿using Newtonsoft.Json;
using System;
using System.ComponentModel.DataAnnotations;

namespace InterviewManagement.Model.Response
{
    public class CandidateModel
    {

        public int CandidateId { get; set; }
        private string _Name { get; set; }
        [JsonIgnore] //To ignore individual properties, use the [JsonIgnore] attribute.
        public string FirstName { get; set; }
        [JsonIgnore]
        public string MiddleName { get; set; }
        [JsonIgnore]
        public string LastName { get; set; }
        [Display(Name = "Full Name")]
        [JsonProperty(Order = -2)] //This is used to order of properties when they are serialized to JSON.
        public string FullName
        {
            get
            {
                var m = !string.IsNullOrEmpty(MiddleName) ? $"{MiddleName} " : "";
                return $"{this.FirstName} {m} {this.LastName} ";
            }
        }
        public char Gender { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Pincode { get; set; }
        public decimal Salary { get; set; }
    }
    public class ListCandidateRetrievalResponseDto : BaseResponseDto
    {
        public List<CandidateModel> candidates { get; set; }
    }
    public class CandidateRetrievalResponseDto : BaseResponseDto
    {
        public CandidateModel candidates { get; set; }
    }
}
