﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace InterviewManagement.Model.Request
{
    public class CandidateRetrievalRequestDto
    {
        [Range(1, int.MaxValue, ErrorMessage = "Please enter valid integer Number")]
        public int CandidateId { get; set; }
        [Required(AllowEmptyStrings = true, ErrorMessage = "First Name is required field")]
        public string FirstName { get; set; }
    }
}
