﻿namespace InterviewManagement.Model.Request
{
    public class TokenApiRequestDto
    {
        public string? AccessToken { get; set; }
        public string? RefreshToken { get; set; }
    }
}
