﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace InterviewManagement.Model.Request
{
    public class CandidateRegisterRequestDto
    {
        [Required(ErrorMessage = "First Name is required field")]
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        [Required(ErrorMessage = "Last Name is required field")]
        public string LastName { get; set; }
        public string Gender { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Pincode { get; set; }
    }
}
