using AutoMapper;
using InterviewManagement.Extensions;
using InterviewManagement.Filters;
using InterviewManagement.Model;
using InterviewManagement.Services.ContractImplementation;
using InterviewManagement.Services.Contracts;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Configuration;
using System.Text;
var builder = WebApplication.CreateBuilder(args);

//Jwt configuration starts here
var jwtIssuer = builder.Configuration.GetSection("Jwt:Issuer").Get<string>();
var jwtKey = builder.Configuration.GetSection("Jwt:Key").Get<string>();
var jwtAudience = builder.Configuration.GetSection("Jwt:Audience").Get<string>();

builder.Services.ConfigureMySqlServerContext(builder.Configuration);//custom extension method for Services.AddDBContext<DBContext>(s=>s.UseSQLServer("<conn_string">);
// Auto Mapper Configurations
/*
var mapperConfig = new MapperConfiguration(mc => {
    mc.AddProfile(new InterviewManagementProfile());
});
IMapper mapper = mapperConfig.CreateMapper();
*/
builder.Services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());
builder.Services.AddScoped<ICandidateService, CandidateService>();
builder.Services.AddTransient<ITokenService, TokenService>();
builder.Services.AddScoped<IServiceTestLifeCycleScope, ServiceTestLifeCycleScope>();
builder.Services.AddTransient<IServiceTestLifeCycleTransient, ServiceTestLifeCycleTransient>();

builder.Services.AddCors(options =>
{
    options.AddPolicy("EnableCORSPolicy", builder =>
    {
        builder.AllowAnyOrigin()
        .AllowAnyHeader()
        .AllowAnyMethod();
    });
});

//Application Service

builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
}).AddJwtBearer(options =>
 {
     options.TokenValidationParameters = new TokenValidationParameters
     {
         ValidateIssuer = true,
         ValidateAudience = true,
         ValidateLifetime = true,
         ValidateIssuerSigningKey = true,
         ValidIssuer = jwtIssuer,
         ValidAudience = jwtAudience,
         IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey)),
         ClockSkew = TimeSpan.Zero //The default value of ClockSkew is 5 minutes. That means if you haven't set it, your token will be still valid for up to 5 minutes. 
     };
 });
//Jwt configuration ends here


// Add services to the container.

//builder.Services.AddControllers();
builder.Services.AddControllers(opt => { 
    opt.SuppressImplicitRequiredAttributeForNonNullableReferenceTypes = true; ///if [Required] is not added on reference properties such as string then also it gives error
    opt.Filters.Add<CustomActionFilter>();
    opt.Filters.Add<CustomGlobalExceptionFilter>(); ////Register global exception filter
    opt.Filters.Add<CustomAuthorizationFilter>();  
});
builder.Services.AddScoped<CustomLocalExceptionFilter>(); //Register local exception filter
builder.Services.AddScoped<CustomResultFilter>(); //Register local exception filter

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
//builder.Services.AddRateLimiter(opt => opt.);
var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
app.UseDeveloperExceptionPage();
app.UseHttpsRedirection();
app.UseCors("EnableCORSPolicy");
app.UseAuthentication();            //Added for JWT Authenctication
app.UseAuthorization();
app.MapControllerRoute(name: "default", pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
