﻿using InterviewManagement.Domain;
using InterviewManagement.Model.Request;
using InterviewManagement.Model.Response;
using InterviewManagement.Services.Contracts;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
//using Microsoft.ApplicationInsights.Extensibility.Implementation;

namespace InterviewManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthenticationController : ControllerBase
    {
        private IConfiguration _config;
        private readonly DBContext _dbContext;
        private readonly ITokenService _tokenService;
        private readonly String key;
        private readonly String issuer;
        private readonly String audience;
       
        public AuthenticationController(IConfiguration config, DBContext dbContext, ITokenService tokenService)
        {
            _config = config;
            _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
            _tokenService = tokenService ?? throw new ArgumentNullException(nameof(tokenService));
            key = _config["Jwt:Key"] ?? "";
            issuer = _config["Jwt:issuer"] ?? "";
            audience = _config["Jwt:audience"] ?? "";
        }

        [HttpPost, Route("login")]
        [AllowAnonymous]
        public IActionResult Login([FromBody] LoginRequestDto loginRequestDto)
        {
            ActionResult? retVal;
            AuthenticatedResponseDto responseDto = new AuthenticatedResponseDto();
            try
            {
                if (loginRequestDto is null)
                {
                    return BadRequest("Invalid client request");
                }
                var user = _dbContext?.Login?.FirstOrDefault(u => (u.UserName == loginRequestDto.UserName) && (u.Password == loginRequestDto.Password));
                if (user is null)
                    return Unauthorized();

                var claims = new List<Claim> {
                new Claim(ClaimTypes.Name, loginRequestDto.UserName),
                new Claim(ClaimTypes.Role, "Operator")
                };

                var accessToken = _tokenService.GenerateAccessToken(claims);
                var refreshToken = _tokenService.GenerateRefreshToken();
                user.RefreshToken = refreshToken;
                user.RefreshTokenExpiryTime = DateTime.UtcNow.AddMinutes(10);
                _dbContext?.SaveChanges();
                retVal = Ok(new AuthenticatedResponseDto { Token = accessToken, RefreshToken = refreshToken });
            }
            catch (Exception)
            {
                responseDto.ErrorMessage = "Login Failed";
                retVal = this.StatusCode(StatusCodes.Status401Unauthorized);

            }
            return retVal;
        }
    }
}
