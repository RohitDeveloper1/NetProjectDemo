﻿using AutoMapper;
using InterviewManagement.Model.Request;
using InterviewManagement.Model.Response;
using InterviewManagement.Services.Contracts;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Candidate = InterviewManagement.Domain.Entities.Candidate;

namespace InterviewManagement.Controllers
{
    [Route("api/[controller]")]
    [EnableCors("EnableCORSPolicy")]
    [ApiController]
    public class CandidateController : ControllerBase
    {
        private readonly ICandidateService _candidateService;
        private readonly IMapper _mapper;
        public CandidateController(ICandidateService candidateService, IMapper mapper)
        {
            _candidateService = candidateService;
            _mapper = mapper;
        }


        [HttpGet("GetAllCandidate"), Authorize(Roles = "Manager")]
        [Authorize]
        public async Task<IActionResult> GetCandidate()
        {
            var candidate = new Candidate();
            var candidateRetrievalResponseDto = new ListCandidateRetrievalResponseDto();
            try
            {
                List<Candidate> lstCandidateEntity = await this._candidateService.GetAllCandidate(candidate);
                
                if (lstCandidateEntity.Any() && lstCandidateEntity.Count > 0)
                {
                    var candidates = _mapper.Map<List<CandidateModel>>(lstCandidateEntity);
                    candidateRetrievalResponseDto.candidates = candidates;
                    candidateRetrievalResponseDto.IsSuccess = true;
                }
            }
            catch (Exception ex)
            {
                candidateRetrievalResponseDto.ErrorMessage = ex.Message;
            }
            return Ok(candidateRetrievalResponseDto);
        }

        [HttpGet("GetCandidate"), Authorize(Roles = "Manager")]
        [Authorize]
        public async Task<IActionResult> GetCandidate([FromQuery] CandidateRetrievalRequestDto candidateRequestDto)
        {
            var candidateRequest = new Candidate();
            var candidateRetrievalResponseDto = new CandidateRetrievalResponseDto();
            try
            {
                if (candidateRequestDto is null)
                {
                    return BadRequest("Candidate object is null");
                }
                _mapper.Map(candidateRequestDto, candidateRequest);
                var candidateEntity = await this._candidateService.GetCandidate(candidateRequest);
                if (candidateEntity != null)
                {
                    CandidateModel candidate = _mapper.Map<CandidateModel>(candidateEntity);
                    candidateRetrievalResponseDto.candidates = candidate;
                    candidateRetrievalResponseDto.IsSuccess = true;
                    //jsonResult = JsonConvert.SerializeObject(candidateRetrievalResponseDto, Formatting.None);
                }
            }
            catch (Exception ex)
            {
                candidateRetrievalResponseDto.ErrorMessage = ex.Message;
            }
            return Ok(candidateRetrievalResponseDto);
        }

        [HttpPost("Register"), Authorize(Roles = "Manager")]
        [Authorize]
        public async Task<IActionResult> RegisterCandidate([FromBody] CandidateRegisterRequestDto candidateRegisterRequestDto)
        {
            var candidate = new Candidate();
            var retVal = new CandidateRegisterResponseDto();
            try
            {
                if (candidateRegisterRequestDto is null)
                {
                    return BadRequest("Candidate object is null");
                }
                _mapper.Map(candidateRegisterRequestDto, candidate);
                var candidateEntity = await this._candidateService.RegisterCandidate(candidate);

                retVal = _mapper.Map<CandidateRegisterResponseDto>(candidateEntity);
                retVal.ErrorMessage = "";
            }
            catch (Exception ex)
            {
                retVal.ErrorMessage = ex.Message;
            }
            return Ok(retVal);
        }
    }
}
