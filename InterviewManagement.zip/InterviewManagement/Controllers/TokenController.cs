﻿using InterviewManagement.Domain;
using InterviewManagement.Model.Request;
using InterviewManagement.Model.Response;
using InterviewManagement.Services.Contracts;
using Microsoft.ApplicationInsights.Extensibility.Implementation;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using static Microsoft.ApplicationInsights.MetricDimensionNames.TelemetryContext;

[Route("api/[controller]")]
[ApiController]
public class TokenController : ControllerBase
{
    private readonly DBContext _dbContext;
    private readonly ITokenService _tokenService;

    public TokenController(DBContext dbContext, ITokenService tokenService)
    {
        this._dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
        this._tokenService = tokenService ?? throw new ArgumentNullException(nameof(tokenService));
    }

    [HttpPost]
    [Route("refresh")]
    [AllowAnonymous]
    public IActionResult Refresh(TokenApiRequestDto tokenApiRequestDto)
    {
        var authenticatedResponseDto = new AuthenticatedResponseDto();
        ActionResult? retVal;
        if (tokenApiRequestDto is null)
            return BadRequest("Invalid client request");

        if (string.IsNullOrEmpty(tokenApiRequestDto.AccessToken) || string.IsNullOrEmpty(tokenApiRequestDto.RefreshToken))
            return BadRequest("Invalid token");

        string accessToken = tokenApiRequestDto.AccessToken;
        string refreshToken = tokenApiRequestDto.RefreshToken;

        var principal = _tokenService.GetPrincipalFromExpiredToken(accessToken);
        var username = principal?.Identity?.Name; //this is mapped to the Name claim by default

        var user = _dbContext?.Login?.SingleOrDefault(u => u.UserName == username);

        if (user is null || user.RefreshToken != refreshToken || user.RefreshTokenExpiryTime <= DateTime.Now)
            return BadRequest("Invalid client request");
        if (principal?.Claims != null)
        {
            var newAccessToken = _tokenService.GenerateAccessToken(principal.Claims);
            var newRefreshToken = _tokenService.GenerateRefreshToken();

            user.RefreshToken = newRefreshToken;
            _dbContext?.SaveChanges();

            authenticatedResponseDto.Token = newAccessToken;
            authenticatedResponseDto.RefreshToken = newRefreshToken;
            retVal = Ok(authenticatedResponseDto);
        }
        else
        {
            authenticatedResponseDto.ErrorMessage = "token generation failed";
            authenticatedResponseDto.IsSuccess = false;
            retVal = this.StatusCode(StatusCodes.Status401Unauthorized, "error message occured while token generation");
        }
        return retVal;
    }

    [HttpPost, Authorize]
    [Route("revoke")]
    public IActionResult Revoke()
    {
        var username = User.Identity.Name;

        var user = _dbContext?.Login?.SingleOrDefault(u => u.UserName == username);
        if (user == null) return BadRequest();

        user.RefreshToken = null;

        _dbContext?.SaveChanges();

        return NoContent();
    }
}