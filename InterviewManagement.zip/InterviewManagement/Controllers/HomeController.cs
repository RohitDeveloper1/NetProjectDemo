﻿using InterviewManagement.Model.Request;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;

namespace InterviewManagement.Controllers
{
    [AllowAnonymous]
    [Route("api/[controller]")]
    [EnableCors("EnableCORSPolicy")]
    [ApiController]
    public class HomeController : ControllerBase
    {
        [HttpGet]
        public IActionResult Index([FromBody] LoginRequestDto loginRequestDto)
        {
            return Ok("Service Started");
        }
    }
}
