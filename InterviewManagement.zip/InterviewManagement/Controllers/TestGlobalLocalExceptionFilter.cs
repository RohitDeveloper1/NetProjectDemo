﻿using InterviewManagement.Filters;
using InterviewManagement.Model.Request;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;

namespace InterviewManagement.Controllers
{
    [AllowAnonymous]
    [Route("api/[controller]")]
    [EnableCors("EnableCORSPolicy")]
    [ApiController]
    public class TestExceptionFilterController : ControllerBase
    {
        [HttpGet("Get")]
        [ServiceFilter(typeof(CustomLocalExceptionFilter))]
        public IActionResult GetWithLoalExceptinHandling1()
        {
            throw new Exception("This is a test exception for local exception handling with local exception filter");
        }

        [HttpGet("DivideByZeroError")]
        [ServiceFilter(typeof(CustomLocalExceptionFilter))]
        public IActionResult GetWithLoalExceptinHandling2()
        {
            throw new DivideByZeroException("Divide by zero in TestGlobalAndLocalExceptionFilterBothController");
        }

        [HttpGet("global")]
        [ServiceFilter(typeof(CustomGlobalExceptionFilter))]
        public IActionResult GetWithGloballExceptinHandling()
        {
            throw new Exception("This is a test exception for global handling with global exception filter");
        }
    }
}
