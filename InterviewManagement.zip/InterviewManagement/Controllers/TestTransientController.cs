﻿using InterviewManagement.Model.Request;
using InterviewManagement.Services.ContractImplementation;
using InterviewManagement.Services.Contracts;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;

namespace InterviewManagement.Controllers
{
    [AllowAnonymous]
    [Route("api/[controller]")]
    [EnableCors("EnableCORSPolicy")]
    [ApiController]
    public class TestTransientController : ControllerBase
    {
        private readonly IServiceTestLifeCycleTransient _service1;
        private readonly IServiceTestLifeCycleTransient _service2;

        public TestTransientController(IServiceTestLifeCycleTransient service1, IServiceTestLifeCycleTransient service2)
        {
            _service1 = service1;
            _service2 = service2;
        }

        [HttpGet]
        public IActionResult Index()
        {
            _service1.Increment();
            _service2.Increment();

            return Ok($"Service 1 value : {_service1.GetValue()} || Service 2 value : {_service2.GetValue()}");

        }
    }
}
