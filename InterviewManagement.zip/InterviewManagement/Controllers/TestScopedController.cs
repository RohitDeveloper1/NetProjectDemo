﻿using InterviewManagement.Model.Request;
using InterviewManagement.Services.Contracts;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.OpenApi.Writers;
using static System.Formats.Asn1.AsnWriter;

namespace InterviewManagement.Controllers
{
    [AllowAnonymous]
    [Route("api/[controller]")]
    [EnableCors("EnableCORSPolicy")]
    [ApiController]
    public class TestScopedController : ControllerBase
    {
        private readonly IServiceTestLifeCycleScope _service1;
        private readonly IServiceTestLifeCycleScope _service2;

        public TestScopedController(IServiceTestLifeCycleScope service1, IServiceTestLifeCycleScope service2)
        {
            _service1 = service1;
            _service2 = service2;
        }

        [HttpGet]
        public IActionResult Index()
        {
            _service1.Increment();
            _service2.Increment();

            return Ok($"Service 1 value : {_service1.GetValue() } || Service 2 value : {_service2.GetValue()}");

        }
    }
}
