﻿using InterviewManagement.Filters;
using InterviewManagement.Model.Request;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;

namespace InterviewManagement.Controllers
{
    [AllowAnonymous]
    [Route("api/[controller]")]
    [EnableCors("EnableCORSPolicy")]
    [ApiController]
    public class TestRegisterFilter : ControllerBase
    {
        [HttpGet("Get")]
        [ServiceFilter(typeof(CustomResultFilter))]
        public IActionResult Get()
        {
            string message = "Welcome";
            return new ObjectResult(message);
        }
    }
}
