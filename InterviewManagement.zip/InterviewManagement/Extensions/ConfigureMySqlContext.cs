﻿using InterviewManagement.Domain;
using InterviewManagement.Domain.Entities;
using Microsoft.EntityFrameworkCore;
namespace InterviewManagement.Extensions
{
    public static class Extensions
    {
        public static void ConfigureMySqlServerContext(this IServiceCollection services, Microsoft.Extensions.Configuration.IConfiguration configuration)
        {
            var connectionString = configuration["mysqlconnection:connectionString"];

            services.AddDbContext<DBContext>(options =>
                 options.UseSqlServer(configuration.GetConnectionString("WebApiDatabase")));

        }
    }
}
