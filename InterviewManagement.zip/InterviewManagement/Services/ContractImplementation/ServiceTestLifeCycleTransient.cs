﻿using InterviewManagement.Services.Contracts;
namespace InterviewManagement.Services.ContractImplementation
{
    public class ServiceTestLifeCycleTransient : IServiceTestLifeCycleTransient
    {
        private static int _instanceCount = 0;
        private readonly int _instanceNumber;
        public ServiceTestLifeCycleTransient()
        {
            _instanceCount++;
            _instanceNumber = _instanceCount;
        }
        public void Increment()
        {
            Console.WriteLine($"Instance {_instanceNumber} : Incremented");
        }
        public int GetValue()
        {
            return _instanceNumber;
        }

    }
}
