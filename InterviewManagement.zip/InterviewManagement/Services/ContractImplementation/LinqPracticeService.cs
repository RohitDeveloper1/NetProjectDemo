﻿using System;
using System.Collections.Generic;
using System.Linq;
namespace InterviewManagement.Services.ContractImplementation
{
    public class Employee
    {
        public int EmpId { get; set; }
        public string EmpName { get; set; }
        public DateTime Hiredate { get; set; }
        public int? ManagerId { get; set; }
    }

    public class Department
    {
        public int DeptId { get; set; }
        public string DeptName { get; set; }
    }

    public class EmpDeptMapper
    {
        public int EmpId { get; set; }
        public int DeptId { get; set; }
    }

    public class Program
    {
        public static void Main()
        {
            var lstEmp = new List<Employee>()
        {
            new Employee() { EmpId = 1, EmpName = "Rohit" ,   Hiredate = Convert.ToDateTime("01/01/2024"), ManagerId = null},
            new Employee() { EmpId = 2, EmpName = "Sanket" ,  Hiredate = Convert.ToDateTime("01/01/2024"), ManagerId = 1},
            new Employee() { EmpId = 3, EmpName = "Manoj" ,   Hiredate = Convert.ToDateTime("01/01/2023"), ManagerId = 2},
            new Employee() { EmpId = 4, EmpName = "Shreays" , Hiredate = Convert.ToDateTime("01/01/2023"), ManagerId = 1}
        };

            var lstDept = new List<Department>()
        {
            new Department() { DeptId = 1, DeptName = "HR" },
            new Department() { DeptId = 1, DeptName = "IT" },
        };

            var lstEmpDeptMapper = new List<EmpDeptMapper>()
        {
            new EmpDeptMapper() { EmpId = 1, DeptId = 1 },
            new EmpDeptMapper() { EmpId = 2, DeptId = 2 },
        };

            //Hired in last year
            var lstHiredLastYear = lstEmp.FindAll(x => x.Hiredate.Year == (DateTime.UtcNow.Year - 1));
            Console.WriteLine(lstHiredLastYear.Count());

            //Avg sal of emp in each Department
            var lstResult = from e in lstEmp
                            join m in lstEmpDeptMapper on e.EmpId equals m.EmpId
                            join d in lstDept on m.DeptId equals d.DeptId
                            select new { EmpId = e.EmpId, EmpName = e.EmpName, DeptName = d.DeptName };
            
            lstResult.ToList().ForEach(x => {
                Console.WriteLine(x.DeptName);
            });

            Console.WriteLine("Hello World");
        }
    }
}
