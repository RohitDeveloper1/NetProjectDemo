﻿using InterviewManagement.Services.Contracts;
using InterviewManagement.Domain;
using InterviewManagement.Domain.Entities;
using InterviewManagement.Model.Response;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.EntityFrameworkCore;
using System.Collections.Immutable;

namespace InterviewManagement.Services.ContractImplementation
{
    public class CandidateService : ICandidateService
    {
        private readonly DBContext _dbContext;

        public CandidateService(DBContext dbContext)
        {
            _dbContext = dbContext;
        }

        public Candidate? GetCandidate(int candidateId)
        {
            return _dbContext.Candidate.Where(x => x.CandidateId == candidateId).FirstOrDefault();
        }

        public async Task<Candidate> GetCandidate(Candidate candidate)
        {


            IQueryable<Candidate> query = null;
            if (!string.IsNullOrEmpty(candidate?.FName))
            {
                query = _dbContext.Candidate.Where(x => x.CandidateId == candidate.CandidateId && x.FName == candidate.FName);
            }
            else
            {
                query = _dbContext.Candidate.Where(x => x.CandidateId == candidate.CandidateId);
            }
            var t = await query.ToListAsync();
            return t.FirstOrDefault();
        }

        public async Task<List<Candidate>> GetAllCandidate(Candidate candidate)
        {
            var result = await _dbContext.Candidate.ToListAsync();
            return result;
        }

        public async Task<Candidate> RegisterCandidate(Candidate candidate)
        {
            this._dbContext.Candidate.Add(candidate);
            int result = await this._dbContext.SaveChangesAsync();
            return result > 0 ? candidate : null;
        }
    }
}
