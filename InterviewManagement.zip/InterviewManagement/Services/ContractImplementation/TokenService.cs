﻿using InterviewManagement.Services.Contracts;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;

namespace InterviewManagement.Services.ContractImplementation
{
    public class TokenService : ITokenService
    {
        private readonly IConfiguration _config;
        private readonly String key;
        private readonly String issuer;
        private readonly String audience;
        private readonly short generateTokenExpiryInMinute;


        public TokenService(IConfiguration config)
        {
            _config = config;
            key = _config["Jwt:Key"] ?? "";
            issuer = _config["Jwt:issuer"] ?? "";
            audience = _config["Jwt:audience"] ?? "";
        }
        public string GenerateAccessToken(IEnumerable<Claim> claims)
        {
            string? tokenString = "";
            if (!string.IsNullOrWhiteSpace(this.key))
            {
                var secretKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(key));
                var signinCredentials = new SigningCredentials(secretKey, SecurityAlgorithms.HmacSha256);

                var tokeOptions = new JwtSecurityToken(
                    issuer: this.issuer,
                    audience: this.audience,
                    claims: claims,
                    expires: DateTime.UtcNow.AddMinutes(1),
                    signingCredentials: signinCredentials
                );

                var tokenDescriptor = new SecurityTokenDescriptor
                {
                    Subject = new ClaimsIdentity(claims),
                    Issuer = this.issuer,
                    Audience = this.audience,
                    Expires = DateTime.UtcNow.AddMinutes(1),
                    SigningCredentials = signinCredentials
                };

                var tokenHandler = new JwtSecurityTokenHandler();
                var token = tokenHandler.CreateToken(tokenDescriptor);
                //tokenString = new JwtSecurityTokenHandler().WriteToken(tokeOptions);
                tokenString = tokenHandler.WriteToken(token);

            }
            return tokenString;
            // JwtSecurityToken, SecurityTokenDescriptor and JwtSecurityTokenHandler are important classes here
        }

        public string GenerateRefreshToken()
        {
            var randomNumber = new byte[32];
            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(randomNumber);
                return Convert.ToBase64String(randomNumber);
            }
        }

        public ClaimsPrincipal GetPrincipalFromExpiredToken(string token)
        {
            var tokenValidationParameters = new TokenValidationParameters
            {
                ValidateAudience = false, //you might want to validate the audience and issuer depending on your use case
                ValidateIssuer = false,
                ValidateIssuerSigningKey = true,
                IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(this.key)),
                ValidateLifetime = false //here we are saying that we don't care about the token's expiration date
            };

            var tokenHandler = new JwtSecurityTokenHandler();
            SecurityToken securityToken;
            var principal = tokenHandler.ValidateToken(token, tokenValidationParameters, out securityToken);
            var jwtSecurityToken = securityToken as JwtSecurityToken;
            if (jwtSecurityToken == null || !jwtSecurityToken.Header.Alg.Equals(SecurityAlgorithms.HmacSha256, StringComparison.InvariantCultureIgnoreCase))
                throw new SecurityTokenException("Invalid token");

            return principal;
        }
    }
}
