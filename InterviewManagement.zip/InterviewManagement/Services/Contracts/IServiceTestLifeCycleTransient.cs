﻿namespace InterviewManagement.Services.Contracts
{
    public interface IServiceTestLifeCycleTransient
    {
        void Increment();
        int GetValue();
    }
}
