﻿
using InterviewManagement.Domain.Entities;

namespace InterviewManagement.Services.Contracts
{
    public interface ICandidateService
    {
        Candidate GetCandidate(int candidateId);
        Task<List<Candidate>> GetAllCandidate(Candidate candidate);
        Task<Candidate> GetCandidate(Candidate candidate);
        Task<Candidate> RegisterCandidate(Candidate candidate);
    }
}
