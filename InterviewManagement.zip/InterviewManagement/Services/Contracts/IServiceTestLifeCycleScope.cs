﻿namespace InterviewManagement.Services.Contracts
{
    public interface IServiceTestLifeCycleScope
    {
        void Increment();
        int GetValue();
    }
}
