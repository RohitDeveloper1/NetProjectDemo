﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Logging;
using System.Diagnostics;
using IActionFilter = Microsoft.AspNetCore.Mvc.Filters.IActionFilter;

namespace InterviewManagement.Filters
{
    public class CustomActionFilter : IActionFilter //IFilter is base interface for IActionFilter
    {
        private readonly ILogger<CustomActionFilter> _logger;
        private Stopwatch _stopwatch;
        public CustomActionFilter(ILogger<CustomActionFilter> logger)
        {
            Console.WriteLine("Action Filter constructor called");
            _logger = logger;
        }
        public void OnActionExecuting(ActionExecutingContext context)
        {
            _stopwatch = Stopwatch.StartNew(); 
            Console.WriteLine("Logging Filter Action's OnActionExecuting method  Called");
            if(!context.ModelState.IsValid)
            {
                context.Result = new BadRequestObjectResult(context.ModelState);
            }

            _logger.LogInformation($"Handling request: Method:{context.HttpContext.Request.Method} , Path: {context.HttpContext.Request.Path}");

        }

        public void OnActionExecuted(ActionExecutedContext context)
        {
            Console.WriteLine("Logging Filter Action's OnActionExecuted method  Called");
            _logger.LogInformation($"Handled request: StatusCode:{context.HttpContext.Response.StatusCode}");
            _stopwatch.Stop();
            _logger.LogInformation($"Action {context.ActionDescriptor.DisplayName} executed in duration{_stopwatch.ElapsedMilliseconds}");

        }
    }
}
