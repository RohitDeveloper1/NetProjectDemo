﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System.Diagnostics;
using IResultFilter = Microsoft.AspNetCore.Mvc.Filters.IResultFilter;

namespace InterviewManagement.Filters
{
    public class CustomResultFilter : IResultFilter //IFilter is base interface for IActionFilter
    {
        private readonly ILogger<CustomResultFilter> _logger;
        private Stopwatch _stopwatch;
        public CustomResultFilter(ILogger<CustomResultFilter> logger)
        {
            Console.WriteLine("Action Filter constructor called");
            _logger = logger;
        }
        public void OnResultExecuting(ResultExecutingContext context)
        {
            _stopwatch = Stopwatch.StartNew();
            Console.WriteLine("Logging Filter Action's OnActionExecuting method  Called");
            //Adding Custom Header
            context.HttpContext.Response.Headers["X-Application-Version"] = "1.0.0";
            _logger.LogInformation($"Handling request: Method:{context.HttpContext.Request.Method} , Path: {context.HttpContext.Request.Path}");
        }

        public void OnResultExecuted(ResultExecutedContext context)
        {
            //Logging and Monitoringv
            _logger.LogInformation($"StatusCode: {context.HttpContext.Response.StatusCode} ContentType: {context.HttpContext.Response.StatusCode}");

            //Transforming Result
            if(context.Result is ObjectResult objectResult)
            {
                var wrappedResult = new { Data = objectResult.Value, Status = "Success", Timestamp = DateTime.UtcNow };
                //context.Result = new ObjectResult(wrappedResult) { StatusCode = objectResult.StatusCode};
                //The above line does not work in .NET Core 8, check on google or chat gpt there is alternative
            }

            //Track API Usage
            _stopwatch.Stop();
            var executionTime = _stopwatch.ElapsedMilliseconds;
            _logger.LogInformation($"API {context.HttpContext.Request.Path} responded in {executionTime}");

        }
    }
}
