﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Logging;
using IExceptionFilter = Microsoft.AspNetCore.Mvc.Filters.IExceptionFilter;

namespace InterviewManagement.Filters
{
    public class CustomLocalExceptionFilter : IExceptionFilter //IFilter is base interface for IActionFilter
    {
        private readonly ILogger<CustomActionFilter> _logger;
        public CustomLocalExceptionFilter(ILogger<CustomActionFilter> logger)
        {
            _logger = logger;
        }
        void IExceptionFilter.OnException(ExceptionContext context)
        {
            Console.WriteLine("Exception Filter Called");
            _logger.LogError(context.Exception, "An unhandled exception occured in local filter");

            if (context.Exception is DivideByZeroException divideByZeroException)
            {
                context.Result = new ObjectResult(new { Error = divideByZeroException.Message })
                { StatusCode = 400 };
            }
            else
            {
                context.Result = new ObjectResult(new { Error = "An error occured while processing your request." })
                { StatusCode = 500 };
            }
            context.ExceptionHandled = true;
        }
    }
}
