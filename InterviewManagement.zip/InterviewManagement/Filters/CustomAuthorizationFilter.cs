﻿using Azure.Core;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Logging;
using IAuthorizationFilter = Microsoft.AspNetCore.Mvc.Filters.IAuthorizationFilter;

namespace InterviewManagement.Filters
{
    public class CustomAuthorizationFilter : IAuthorizationFilter //IFilter is base interface for IActionFilter
    {
        void IAuthorizationFilter.OnAuthorization(AuthorizationFilterContext context)
        {
            Console.WriteLine("Authorization Filter Called");
            var user = context.HttpContext.User;
            
            var endPoint = context.HttpContext.GetEndpoint();
            if(endPoint?.Metadata?.GetMetadata<IAllowAnonymous>() != null)
            {
                return;
            }
            if(!user.Identity.IsAuthenticated)
            {
                context.Result = new ForbidResult();
            }
        }
    }
}
