﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace InterviewManagement.Domain.Entities
{
    [Table("tblCandidate")]
    public class Candidate
    {
        [Required(ErrorMessage = "CandidateId is required field")]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int CandidateId { get; set; }
        [Required(ErrorMessage = "First Name is required field")]
        public string FName { get; set; }
        public string MName { get; set; }
        [Required(ErrorMessage = "Last Name is required field")]
        public string LName { get; set; }
        public string Gender { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Pincode { get; set; }
        public decimal Salary { get; set; }
    }
}

