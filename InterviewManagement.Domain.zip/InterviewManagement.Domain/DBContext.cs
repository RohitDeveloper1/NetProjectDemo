﻿using InterviewManagement.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace InterviewManagement.Domain
{
    public class DBContext : DbContext
    {
       
        protected readonly IConfiguration Configuration;
        public DBContext(IConfiguration configuration)
        {
            Configuration = configuration;
        }
        protected override void OnConfiguring(DbContextOptionsBuilder options)
        {
            // connect to sql server with connection string from app settings
            options.UseSqlServer(Configuration.GetConnectionString("WebApiDatabase"));
        }
        public DbSet<Candidate> Candidate { get; set; }

        public DbSet<Login>? Login { get; set; }

    }
}
